<ul class="nav-links">
                        <li>
                          <a href="<?php echo base_url().'Welcome/dashboard';?>">
                            <i class='bx bx-grid-alt' ></i>
                            <span class="link_name">Dashboard</span>
                          </a>
                         
                        </li>
                        <li class="active">
                          <div class="iocn-link">
                            <a href="#">
                              <i class='bx bx-collection' ></i>
                              <span class="link_name">Core Content</span>
                            </a>
                            <i class='bx bxs-chevron-down arrow' ></i>
                          </div>
                          <ul class="sub-menu">
                           
                            <li><a href="<?php echo base_url().'Welcome/listsiteinformation';?>">Primary Info / Logo & Favicon </a></li>
                           
                            <li><a href="core-content-email.html">Site Emails / Contact Details </a></li>
                            <li><a href="<?php echo base_url().'Welcome/listsocialmedialinks';?>">Social Media Links / Meta Tages</a></li>
                            
                          </ul>
                        </li>
                        <li>
                          <div class="iocn-link">
                            <a href="#">
                              <i class='bx bx-book-alt' ></i>
                              <span class="link_name">Page Content</span>
                            </a>
                            <i class='bx bxs-chevron-down arrow' ></i>
                          </div>
                          <ul class="sub-menu">
                          
                                <li><a href="<?php echo base_url().'Welcome/listhomepage';?>">Home Page</a></li>
                                <li><a href="<?php echo base_url().'Welcome/listaboutus';?>">About Us</a></li>
                              
                               
                                <li><a href="<?php echo base_url().'Welcome/listcontactus';?>">Contact Page</a></li>
                                                      
                          </ul>
                        </li>               
                      
                    

                              <li>
                              <a href="<?php echo base_url().'Welcome/addfeatureupdate';?>">
                                <i class='bx bx-compass' ></i>
                                <span class="link_name">Add Feature Icon</span>
                              </a>
                              
                            </li>

                           
                            <li>
                              <a href="<?php echo base_url().'Welcome/adddestination';?>">
                                <i class='bx bx-compass' ></i>
                                <span class="link_name">Add Works</span>
                              </a>
                              
                            </li>
                            <li>
                              <a href="<?php echo base_url().'Welcome/addtourservices';?>">
                                <i class='bx bx-compass' ></i>
                                <span class="link_name">Add Services</span>
                              </a>
                              
                            </li>

                            


                        
                        <li>
                                <a href="<?php echo base_url().'Welcome/addcarousel';?>">
                                  <i class='bx bx-compass'></i>
                                  <span class="link_name">Add Carousal</span>
                                </a>
                              
                              </li>
                        <li>

                        <li>
                                <a href="<?php echo base_url().'Welcome/addauthority';?>">
                                  <i class='bx bx-compass'></i>
                                  <span class="link_name">Add Clients</span>
                                </a>
                              
                              </li>
                              <li>

                                <a href="<?php echo base_url().'Welcome/addpackages';?>">
                                  <i class='bx bx-compass'></i>
                                  <span class="link_name">Add Advertisement</span>
                                </a>
                              
                              </li>
                      
                        <li>
                              <a href="<?php echo base_url().'Welcome/addtestimonials';?>">
                                <i class='bx bx-compass' ></i>
                                <span class="link_name">Add Testimonials</span>
                              </a>
                              
                            </li>
                            <li>
                              <a href="<?php echo base_url().'Welcome/addteammembers';?>">
                                <i class='bx bx-compass' ></i>
                                <span class="link_name">Add Team Members</span>
                              </a>
                              
                            </li>
                            <li>
                              <a href="<?php echo base_url().'Welcome/addfaq';?>">
                                <i class='bx bx-compass' ></i>
                                <span class="link_name">Add Categories</span>
                              </a>
                              
                            </li>
                       
                            <li>
                              <a href="<?php echo base_url().'Welcome/listcontactenquiries';?>">
                                <i class='bx bx-history'></i>
                                <span class="link_name">Contact Enquiry</span>
                              </a>
                            
                            </li>
                          

                            
                            <li>
                              <div class="iocn-link">
                                <a href="#">
                                  <i class='bx bx-plug' ></i>
                                  <span class="link_name">Newsletter</span>
                                </a>
                                <i class='bx bxs-chevron-down arrow' ></i>
                              </div>
                              <ul class="sub-menu">
                                <li><a class="link_name" href="#">Plugins</a></li>
                                <li><a href="<?php echo base_url().'Welcome/newsletter';?>">Newsletter View</a></li>
                                <li><a href="<?php echo base_url().'Welcome/newslettersubscribers';?>">Newsletter Subscribers</a></li>
                              
                              </ul>
                            </li>
                           


                        <li>
                                <a href="<?php echo base_url().'index.php/Welcome/logout';?>">
                                  <i class='bx bx-history'></i>
                                  <span class="link_name">Logout</span>
                                </a>
                              
                              </li>
                        
                    
                  </ul>