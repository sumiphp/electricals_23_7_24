<!--!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Lalgy Printers & Advertisers</title>
  <meta content="India’s leading out-of-home agency in its class.
  Lalgy Printers was started in the year 1981 and running successfully as a leading printing and advertising firm in Central Travencore." name="description">
  <meta content="lalgy advertisers & printers, lalgy, advertising, printing, best advertising agency in kerala, best advertising agency in kottayam" name="keywords">
  <meta content="lalgy" name="keywords">

  
  <link href="assets/img/favicon.ico" rel="icon">
  
  <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,500,600,700" rel="stylesheet">
 
  
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/responsive.css" rel="stylesheet">
  
</head>

<body>

 
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto"><img src="assets/img/logo.jpg" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="index.html">Home</a></li>
          <li><a class="nav-link scrollto" href="about.html">About</a></li>
          <li><a class="nav-link scrollto" href="service.html">Services</a></li>
          <li><a class="nav-link   scrollto" href="our-work.html">Our Work</a></li>
          <li><a class="nav-link   scrollto" href="advertisers.html">advertisers</a></li>
          <li><a class="nav-link scrollto" href="contact.html">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <button type="button" class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01">
        <i class="bi bi-search"></i>
      </button>
    </div>
  </header-->





  <?php include('header.php');?>
  <style>
.btn {
  background: #cb413e;
  border-radius: 30px;
  border: none;
  padding: 5px 20px;
  text-align: center;
  color: #fff;
  margin-top: 10px;
  width: 100%;
}

</style>

  <main id="main">

   <div class="contact-deatils section-t8" style="background-image: url(assets/img/conact.png);background-repeat: no-repeat;background-size: cover;">
    <div class="container">
      <div class="contact-form">
        <div class="row">
          <div class="col-lg-6 col-md-6">
            <div class="left-form">
              <h2>Get In Touch</h2>
              <form class="form-a" method="post" action="<?php echo base_url().'lalgy/contactenquiryprocess';?>" name="frmcontact" id="frmcontact">
                <div class="row">
                  <div class="col-md-12 mb-2">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-lg form-control-a" placeholder="Name" id="first_name" name="first_name"  >
                    </div>
                  </div>
                  <div class="col-md-12 mb-2">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-lg form-control-a" placeholder="Email" id="email" name="email" >
                    </div>
                  </div>
                  <div class="col-md-12 mb-2">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-lg form-control-a" placeholder="PhoneNumber" id="phone" name="phone">
                    </div>
                  </div>

                  <div class="col-md-12 mb-2">
                    <div class="form-group">
                      <label class="pb-2" for="Type">Select Purpose of Contact</label>
                      <input type="text" class="form-control form-control-lg form-control-a" placeholder="Type of work" id="purpose" name="purpose">
                    </div>
                  </div>

                  <div class="col-md-12 mb-2">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-lg form-control-a" placeholder="Subject" id="subject" name="subject">
                    </div>
                  </div>

                  <div class="col-md-12 mb-2">
                    <div class="form-group">
                      <input type="text" class="form-control form-control-lg form-control-a" placeholder="Message" id="message" name="message">
                    </div>
                  </div>
                
                 
               
               
                
                
                  <div class="col-md-12">
                    <button type="submit" class="btn btn-b">Send</button>
                    
                    
                    
                    
                    &nbsp;<span class="msg" style='color:#fff'></span>
                  </div>
                </div>
              </form>
            </div>
           
          </div>
          <div class="col-lg-6 col-md-6">
            <div class="right-map">
              <!--iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%; height: 434px;" allowfullscreen=""></iframe-->
                <iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3936.412069949042!2d76.57264043863749!3d9.385183090729834!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b06247267357811%3A0xa5e97b8e5264a217!2sLalgy%20Printers%20%26%20Advertisers!5e0!3m2!1sen!2sin!4v1713008642191!5m2!1sen!2sin" frameborder="0" style="border:0; width: 100%; height:434px;" allowfullscreen=""></iframe>
              
            </div>
          </div>
        </div>
      </div>
    </div>
   </div>

  </main><!-- End #main -->
  
  <section class="section-footer no-mar">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Newsletter</h3>
            </div>
            <div class="w-body-a">
              <p class="w-text-a color-text-a">
              <?php echo $newsletter->newsletterdescription;?>
              </p>
            </div>
            <div class="newsletter-area">
              <form action="" method="post">
                <!--input type="email" name="email"><input type="submit" value="Subscribe"-->
                <div id='newsmsg' style='color:#fff'></div>

                <input type="email" name="email" id="emailidnews1" name="emailidnews1" placeholder="Email Address">
                <input type="button" value="Subscribe" class=btn onclick="sub()";>
               




              </form>
              
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Information</h3>
            </div>
            <div class="w-body-a">
              <div class="w-body-a">
                <ul class="list-unstyled">
                <li class="item-list-a">
                   <a href="<?php echo base_url().'lalgy/index';?>">Home</a>
                  </li>
                  <li class="item-list-a">
                  <a href="<?php echo base_url().'lalgy/about';?>">About</a>
                  </li>
                  <li class="item-list-a">
                 <a href="<?php echo base_url().'lalgy/services';?>">Services</a>
                  </li>
                  <li class="item-list-a">
                 <a href="<?php echo base_url().'lalgy/ourwork';?>">Our Work</a>
                  </li>
                  <li class="item-list-a">
                 <a href="<?php echo base_url().'lalgy/advertisers';?>">Advertisers</a>
                  </li>
                  <li class="item-list-a">
                 <a href="<?php echo base_url().'lalgy/contact';?>">Contact</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Customer Service</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
              <?php $this->db2->select('*');
    $this->db2->from('faq');
    $query = $this->db2->get();
    $catdt=$query->result_array();
    //print_r($footerdt);
    
    ?>
    <?php foreach($catdt as $cat){?>



    
                <li class="item-list-a">
              <a href="<?php echo base_url().'lalgy/services';?>"><?php echo $cat['faqtitle'];?></a>
                </li>
              <?php }?>
                <!--li class="item-list-a">
              <a href="#">Venezuela</a>
                </li>


                <li class="item-list-a">
                  <a href="#">China</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Hong Kong</a>
                </li>
                <li class="item-list-a">
                <a href="#">Argentina</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Singapore</a>
                </li>
                <li class="item-list-a">
                  <a href="#">Philippines</a>
                </li-->
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Contact</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
                <a href="#"><?php echo $contactus->street;?></a>
                </li>
                <li class="item-list-a">
                  <a href="#">   <i class="bi bi-envelope"></i> <?php echo $contactus->emailid;?></a>
               </li>

               <li class="item-list-a">
                 <a href="tel:<?php echo $contactus->phoneno;?>">  <i class="bi bi-telephone"></i>  <?php echo $contactus->phoneno;?></a>
              </li>
               
              </ul>
            </div>





            <?php $this->db2->select('*');
    $this->db2->from('socialmedialinks');
    $query = $this->db2->get();
    $footerdt=$query->row();
    //print_r($footerdt);
    
    ?>
                            

            <div class="socials-a">
              <ul class="list-inline">
                <li class="list-inline-item">
                <a href="<?php echo $footerdt->facebook;?>" target=_blank>
                    <i class="bi bi-facebook" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                <a href="<?php echo $footerdt->twitter;?>" target=_blank>
                    <i class="bi bi-twitter" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                <a href="<?php echo $footerdt->instagram;?>" target=_blank>
                    <i class="bi bi-instagram" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                <a href="<?php echo $footerdt->linkldn;?>" target=_blank>

                    <i class="bi bi-linkedin" aria-hidden="true"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
                </section>
  <!--footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright 
            <B> Lalgy Printers & Advertisers </B> . All Rights Reserved.
            </p>
          </div>
         
        </div>
      </div>
    </div>
  </footer-->

  <!--div id="preloader"></div-->
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  



  <script src="<?php echo base_url().'lalgy/assets/vendor/bootstrap/js/bootstrap.bundle.min.js';?>"></script>
  <script src="<?php echo base_url().'lalgy/assets/vendor/swiper/swiper-bundle.min.js';?>"></script>
  <script src="<?php echo base_url().'lalgy/assets/vendor/php-email-form/validate.js';?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url().'lalgy/assets/js/main.js';?>"></script>
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script><!-- jQuery base library needed -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"> </script>

  <?php //include('footer.php');?>



  <script>

 function sub(){
    //alert("sub");
    var news1=$('#emailidnews1').val();
    var id=$('#emailidnews1').val();
	var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
    if (news1==''){
        $('#newsmsg').html('Please enter Email Id');

    }
    else if (!(testEmail.test(id))){
        $('#newsmsg').html('Please enter Valid Email Id');

    }
    else{
    
    //$("#myForm").submit();
    var emailidnews1=$('#emailidnews1').val();
    var url1="<?php echo base_url().'lalgy/newslettersubscribe';?>"
    $.ajax({
url:url1,
method:"get",
data:{emailidnews1:emailidnews1},
dataType:'text',
crossDomain:true,
success: function(response) {
$('input[type=text]').each(function() {
$(this).val('');
});

$('#emailidnews1').val('');

$('#newsmsg').html(response);

}
               
});		

} 

}


$('form[id="frmcontact"]').validate({  
    rules: {  
      first_name: 'required',  
      //last_name: 'required',
      phone:'required',  
      email: {  
        required: true,  
        email: true,  
      },
      purpose:"required", 
      subject:"required",
      message:"required", 
      /*psword: {  
        required: true,  
        minlength: 8,  
      }*/  
    },  
    messages: {  
       first_name: '<font color=#fff>First Name is required</font>',  
        //last_name: 'Last Name is required',  
      phone: '<font color=#fff>Enter a valid Phone</font>',
      email: '<font color=#fff>Enter a valid Email</font>',  
      /*psword: {  
        minlength: 'Password must be at least 8 characters long'  
      } */
      purpose: '<font color=#fff>Enter Purpose</font>',
       subject: '<font color=#fff>Enter Subject</font>',
      message:'<font color=#fff>Please enter Message</font>' 
    },  
    submitHandler: function(form) { 
     
            $.ajax({
	url: form.action,
	type: form.method,
	data: $(form).serialize(),
	success: function(response) {
        $('input[type=text]').each(function() {
        $(this).val('');
    });
    
    $("#email").val('');
    $("#message").val('');
    
		$('.msg').html(response);
	}            
      });		
}





      //form.submit();  
   // }  
  });  
  </script>






</body>

</html>