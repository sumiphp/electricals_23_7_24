<!--!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Lalgy Printers & Advertisers</title>
  <meta content="India’s leading out-of-home agency in its class.
  Lalgy Printers was started in the year 1981 and running successfully as a leading printing and advertising firm in Central Travencore." name="description">
  <meta content="lalgy advertisers & printers, lalgy, advertising, printing, best advertising agency in kerala, best advertising agency in kottayam" name="keywords">
  <meta content="lalgy" name="keywords">

 
  

  <link href="assets/img/favicon.ico" rel="icon">
  
  <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,500,600,700" rel="stylesheet">

  
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/responsive.css" rel="stylesheet">
  
</head>

<body>



  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto"><img src="assets/img/logo.jpg" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="index.html">Home</a></li>
          <li><a class="nav-link scrollto" href="about.html">About</a></li>
          <li><a class="nav-link scrollto" href="service.html">Services</a></li>
          <li><a class="nav-link   scrollto" href="our-work.html">Our Work</a></li>
          <li><a class="nav-link   scrollto" href="advertisers.html">advertisers</a></li>
          <li><a class="nav-link scrollto" href="contact.html">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <button type="button" class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01">
        <i class="bi bi-search"></i>
      </button>
    </div>
  </header-->
  <?php include('header.php');?>

  <main id="main">

    <!-- ======= Intro Single ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single"><?php echo $about->title;?></h1>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="<?php echo base_url().'lalgy/index';?>">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  About
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- End Intro Single-->

    <!-- ======= About Section ======= -->
    <section class="section-about">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 position-relative">
            <div class="about-img-box">
            <?php $url=base_url().'uploads/aboutus/'.$about->aboutusbanner;?>

              <img src="<?php echo $url;?>" alt="" class="img-fluid">
            </div>
            <div class="sinse-box">
              <h3 class="sinse-title">Lalgy
                <span></span>
                <br> Printer and advertisers
              </h3>
              <p><?php echo $about->aboutusshortdesc;?></p>
            </div>
          </div>
          <div class="col-md-12 section-t4 position-relative">
            <div class="row">
              <div class="col-md-6 col-lg-6">
                <div class="title-box-d">
                  <h3 class="title-d">Mission
                    
                 
                  </h3>
                </div>
                <p class="color-text">
                <?php echo $about->mission;?>
                </p>
                <p class="color-text">
                <?php echo $about->mission;?>
                </p>
                
              </div>
             
              <div class="col-md-6 col-lg-6">
                <div class="title-box-d">
                  <h3 class="title-d">Vision
                   
                 
                  </h3>
                </div>
                <p class="color-text">
                <?php echo $about->vision;?>
                </p>

                <p class="color-text">
                <?php echo $about->vision;?>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="counts" class="counts">
      <div class="container aos-init aos-animate" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="count-box">
              <i class="bi bi-emoji-smile"></i>
              <span data-purecounter-start="0" data-purecounter-end="232" data-purecounter-duration="0" class="purecounter"><?php echo $about->happyclients;?></span>
              <p>Happy Clients</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
            <div class="count-box">
              <i class="bi bi-journal-richtext"></i>
              <span data-purecounter-start="0" data-purecounter-end="521" data-purecounter-duration="0" class="purecounter"><?php echo $about->nohotels;?></span>
              <p>Projects</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="bi bi-headset"></i>
              <span data-purecounter-start="0" data-purecounter-end="1463" data-purecounter-duration="0" class="purecounter"> <?php echo $about->notravels;?></span>
              <p>Years of Experience</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="bi bi-people"></i>
              <span data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="0" class="purecounter"><?php echo $about->nowinning;?></span>
              <p>Awards</p>
            </div>
          </div>

        </div>

      </div>
    </section>
    <!-- =======Team Section ======= -->
    <section class="section-agents section-t8">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="title-wrap">
              <div class="title-box">
                <h2 class="title-a text-center">Meet Our Team</h2>
              </div>
            </div>
          </div>
        </div>
        <div class="row">


        <?php foreach($resultdata as $con){?>


<?php $url=base_url().'uploads/teammembers/'.$con['picture'];?>
<div class="col-md-4">
  <div class="card-box-d">
    <div class="card-img-d">
      <img src="<?php echo $url;?>" alt="" class="img-d img-fluid">
    </div>
    <div class="card-overlay card-overlay-hover">
      <div class="card-header-d">
        <div class="card-title-d align-self-center">
          <h3 class="title-d">
            <a href="#" class="link-two"><?php echo $con['name'];?>
            
          </h3>
        </div>
      </div>
      <div class="card-body-d">
        <p class="content-d color-text-a">
        <?php echo $con['designation'];?>
        </p>
        <div class="info-agents color-a">
          <p>
            <strong>Phone: </strong> +<?php echo $con['namear'];?>
          </p>
          <p>
            <strong>Email: </strong>   <?php echo $con['designationar'];?>
          </p>
        </div>
      </div>
      <div class="card-footer-d">
        <div class="socials-footer d-flex justify-content-center">
          <ul class="list-inline">
            <li class="list-inline-item">
              <a href="<?php echo $con['facebook'];?>" target=_blank class="link-one">
                <i class="bi bi-facebook" aria-hidden="true"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="<?php echo $con['twitter'];?>" class="link-one" target=_blank>
                <i class="bi bi-twitter" aria-hidden="true"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="<?php echo $con['instagram'];?>" class="link-one" target=_blank>
                <i class="bi bi-instagram" aria-hidden="true"></i>
              </a>
            </li>
            <li class="list-inline-item">
              <a href="<?php echo $con['youtube'];?>" class="link-one" target=_blank>
                <i class="bi bi-linkedin" aria-hidden="true"></i>
              </a>
            </li>
          </ul>
        </div>
      </div>




    </div>
  </div>
</div>

<?php } ?>


          <!--div class="col-md-4">
            <div class="card-box-d">
              <div class="card-img-d">
                <img src="assets/img/team-1.png" alt="" class="img-d img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                <div class="card-header-d">
                  <div class="card-title-d align-self-center">
                    <h3 class="title-d">
                      <a href="#" class="link-two">Margaret Sotillo
                      
                    </h3>
                  </div>
                </div>
                <div class="card-body-d">
                  <p class="content-d color-text-a">
                    Sed porttitor lectus nibh, Cras ultricies ligula sed magna dictum porta two.
                  </p>
                  <div class="info-agents color-a">
                    <p>
                      <strong>Phone: </strong> +54 356 945234
                    </p>
                    <p>
                      <strong>Email: </strong> agents@example.com
                    </p>
                  </div>
                </div>
                <div class="card-footer-d">
                  <div class="socials-footer d-flex justify-content-center">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-linkedin" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card-box-d">
              <div class="card-img-d">
                <img src="assets/img/team-2.png" alt="" class="img-d img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                <div class="card-header-d">
                  <div class="card-title-d align-self-center">
                    <h3 class="title-d">
                      <a href="#" class="link-two">Stiven Spilver
                     
                    </h3>
                  </div>
                </div>
                <div class="card-body-d">
                  <p class="content-d color-text-a">
                    Sed porttitor lectus nibh, Cras ultricies ligula sed magna dictum porta two.
                  </p>
                  <div class="info-agents color-a">
                    <p>
                      <strong>Phone: </strong> +54 356 945234
                    </p>
                    <p>
                      <strong>Email: </strong> agents@example.com
                    </p>
                  </div>
                </div>
                <div class="card-footer-d">
                  <div class="socials-footer d-flex justify-content-center">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-linkedin" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-dribbble" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div-->
          <!--div class="col-md-4">
            <div class="card-box-d">
              <div class="card-img-d">
                <img src="assets/img/team-1.png" alt="" class="img-d img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                <div class="card-header-d">
                  <div class="card-title-d align-self-center">
                    <h3 class="title-d">
                      <a href="#" class="link-two">Emma Toledo
                      
                    </h3>
                  </div>
                </div>
                <div class="card-body-d">
                  <p class="content-d color-text-a">
                    Sed porttitor lectus nibh, Cras ultricies ligula sed magna dictum porta two.
                  </p>
                  <div class="info-agents color-a">
                    <p>
                      <strong>Phone: </strong> +54 356 945234
                    </p>
                    <p>
                      <strong>Email: </strong> agents@example.com
                    </p>
                  </div>
                </div>
                <div class="card-footer-d">
                  <div class="socials-footer d-flex justify-content-center">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-linkedin" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-dribbble" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div-->
        </div>
      </div>
    </section><!-- End About Section-->


     <!--======= CliENT Section ===-->

     <section class="section-property section-t8 bg-color">
      <div class="container aos-init aos-animate" data-aos="zoom-in">
        <div class="row">
          <div class="col-md-12">
            <div class="our-work-area">
              <div class="title-box text-center">
                <h2 class="single-title mb-5">OUR CLIENTS</h3>
              </div>
            
            </div>
          </div>
        </div>

        <div id="property-carousel" class="swiper">
          <div class="swiper-wrapper">
          <?php foreach($resultdata1 as $con){?>
            <?php $url=base_url().'uploads/authority/'.$con['picture'];?>
            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                  <img src="<?php echo $url;?>" class="img-fluid" alt="">
              </div>
            </div>
            <?php } ?>

            <!--div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (2).png" class="img-fluid" alt="">
            </div>
            </div>
            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (3).png" class="img-fluid" alt="">
            </div>
            </div>

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (4).png" class="img-fluid" alt="">
            </div>
            </div>

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (5).png" class="img-fluid" alt="">
            </div>
            </div-->

          </div>
        </div>
        <div class="propery-carousel-pagination carousel-pagination"></div>

      </div>
    </section><!-- End Latest Properties Section -->

  </main><!-- End #main -->
 <!-- ======= Contact Section ======= -->
 <section id="contact" class="contact">
  <div class="container aos-init aos-animate" data-aos="fade-up">

    <div class="row">
      <div class="col-md-12">
        <div class="testimonial-wrap title-wrap">
          <div class="title-box ">
            <h2 class="single-title text-center">CONTACT DETAILS</h3>
           
          </div>
        </div>
      </div>
    </div>

    

    <div class="row aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">

      <div class="col-lg-6 ">
        <!--iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%; height: 384px;" allowfullscreen=""></iframe-->


          <iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3936.412069949042!2d76.57264043863749!3d9.385183090729834!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b06247267357811%3A0xa5e97b8e5264a217!2sLalgy%20Printers%20%26%20Advertisers!5e0!3m2!1sen!2sin!4v1713008642191!5m2!1sen!2sin" frameborder="0" style="border:0; width: 100%; height:384px;" allowfullscreen=""></iframe>
      </div>

      <div class="col-lg-6">
       <form  method="post" role="form" class="php-email-form" id='frmcontact' action="<?php echo base_url().'lalgy/contactenquiryprocess';?>">
          <div class="row">
            <div class="col form-group">
              <input type="text" name="first_name" class="form-control" id="first_name" placeholder="Your Name" required="">
            </div>
            <div class="col form-group">
              <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required="">
            </div>
          </div>
          <div class="form-group">
            <!--input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required=""-->

 <input type="text" class="form-control" name="phone" id="phone" placeholder="Phone No" required="">

          </div>
          <div class="form-group">
            <textarea class="form-control" name="message" id="message" rows="5" placeholder="Message" required=""></textarea>
          </div>
          <div class="my-3">
            <div class="loading1"></div>
            <div class="error-message1 msg"></div>
            <div class="sent-message">Your message has been sent. Thank you!</div>
          </div>
          <div class="text-center"><button type="submit">Send Message</button></div>
        </form>
      </div>

    </div>

  </div>
</section>
   <!-- ======= Footer ======= -->
   <!--section class="section-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Newsletter</h3>
            </div>
            <div class="w-body-a">
              <p class="w-text-a color-text-a">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
              </p>
            </div>
            <div class="newsletter-area">
              <form action="" method="post">
                <input type="email" name="email"><input type="submit" value="Subscribe">
              </form>
              
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Information</h3>
            </div>
            <div class="w-body-a">
              <div class="w-body-a">
                <ul class="list-unstyled">
                  <li class="item-list-a">
                   <a href="#">Site Map</a>
                  </li>
                  <li class="item-list-a">
                  <a href="#">Legal</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Agent Admin</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Careers</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Affiliate</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Privacy Policy</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Customer Service</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
              <a href="#">Venezuela</a>
                </li>
                <li class="item-list-a">
                  <a href="#">China</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Hong Kong</a>
                </li>
                <li class="item-list-a">
                <a href="#">Argentina</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Singapore</a>
                </li>
                <li class="item-list-a">
                  <a href="#">Philippines</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Contact</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
                <a href="#">768 Market Street San Francisco, CA 64015, United States</a>
                </li>
                <li class="item-list-a">
                  <a href="#">   <i class="bi bi-envelope"></i> Customer@gmail.com</a>
               </li>

               <li class="item-list-a">
                 <a href="tel:6743292022">  <i class="bi bi-telephone"></i>  6743292022</a>
              </li>
               
              </ul>
            </div>

            <div class="socials-a">
              <ul class="list-inline">
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-facebook" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-twitter" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-instagram" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-linkedin" aria-hidden="true"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright 
            <B> Lalgy Printers & Advertisers </B> . All Rights Reserved.
            </p>
          </div>
         
        </div>
      </div>
    </div>
  </footer>

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

 
  <script src="assets/js/main.js"></script>
  <script src="assets/vendor/aos/aos.js"></script-->
  <?php include('footer.php');?>

</body>

</html>