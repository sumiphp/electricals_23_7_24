 <!-- ======= Footer ======= -->

 <style>
.btn{
background: #cb413e;
  border-radius: 30px;
  border: none;
  padding: 5px 20px;
  text-align: center;
  color: #fff;
  margin-top: 10px;
  width: 100%;
}

  </style>
   <section class="section-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Newsletter</h3>
            </div>
            <div class="w-body-a">
              <p class="w-text-a color-text-a">
              <?php echo $newsletter->newsletterdescription;?>
              </p>
            </div>
            <div class="newsletter-area">
              <form action="#" method="post">
                <input type="email" name="email" id="emailidnews1" name="emailidnews1" placeholder="Email Address"><input onclick="sub()"; class='btn' type="button" value="Subscribe">


                <!--input type="email" id="emailidnews1" name="emailidnews1" placeholder="Email Address"><br> 
                 
                                  <button  type="submit"  onclick="sub()"; >Subscribe</button-->
                                  <div id='newsmsg' style='color:#fff'></div>



              </form>
              
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Information</h3>
            </div>
            <div class="w-body-a">
              <div class="w-body-a">
                <ul class="list-unstyled">
                  <li class="item-list-a">
                   <a href="<?php echo base_url().'lalgy/index';?>">Home</a>
                  </li>
                  <li class="item-list-a">
                  <a href="<?php echo base_url().'lalgy/about';?>">About</a>
                  </li>
                  <li class="item-list-a">
                 <a href="<?php echo base_url().'lalgy/services';?>">Services</a>
                  </li>
                  <li class="item-list-a">
                 <a href="<?php echo base_url().'lalgy/ourwork';?>">Our Work</a>
                  </li>
                  <li class="item-list-a">
                 <a href="<?php echo base_url().'lalgy/advertisers';?>">Advertisers</a>
                  </li>
                  <li class="item-list-a">
                 <a href="<?php echo base_url().'lalgy/contact';?>">Contact</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Our Services</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">

              <?php $this->db2->select('*');
    $this->db2->from('faq');
    $query = $this->db2->get();
    $catdt=$query->result_array();
    //print_r($footerdt);
    
    ?>
    <?php foreach($catdt as $cat){?>



    
                <li class="item-list-a">
              <a href="<?php echo base_url().'lalgy/services';?>"><?php echo $cat['faqtitle'];?></a>
                </li>
              <?php }?>
                <!--li class="item-list-a">
                  <a href="#">China</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Hong Kong</a>
                </li>
                <li class="item-list-a">
                <a href="#">Argentina</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Singapore</a>
                </li>
                <li class="item-list-a">
                  <a href="#">Philippines</a>
                </li-->
              </ul>
            </div>
          </div>
        </div>



        
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Contact</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
                <a href="#"> <?php echo $contactus->street;?></a>
                </li>
                <li class="item-list-a">
                  <a href="#">   <i class="bi bi-envelope"></i> <?php echo $contactus->emailid;?></a>
               </li>

               <li class="item-list-a">
                 <a href="tel:6743292022">  <i class="bi bi-telephone"></i>  <?php echo $contactus->phoneno;?></a>
              </li>
               
              </ul>
            </div>




            <?php $this->db2->select('*');
    $this->db2->from('socialmedialinks');
    $query = $this->db2->get();
    $footerdt=$query->row();
    //print_r($footerdt);
    
    ?>
                            

            <div class="socials-a">
              <ul class="list-inline">
                <li class="list-inline-item">
                  <a href="<?php echo $footerdt->facebook;?>" target=_blank>
                    <i class="bi bi-facebook" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="<?php echo $footerdt->twitter;?>" target=_blank>
                    <i class="bi bi-twitter" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="<?php echo $footerdt->instagram;?>" target=_blank>
                    <i class="bi bi-instagram" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="<?php echo $footerdt->linkldn;?>" target=_blank>
                    <i class="bi bi-linkedin" aria-hidden="true"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright 
            <B> Lalgy Printers & Advertisers </B> . All Rights Reserved.
            </p>
          </div>
         
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <!--script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script--> 
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script><!-- jQuery base library needed -->
  <script src="<?php echo base_url().'lalgy/assets/vendor/bootstrap/js/bootstrap.bundle.min.js';?>"></script>
  <script src="<?php echo base_url().'lalgy/assets/vendor/swiper/swiper-bundle.min.js';?>"></script>
  <script src="<?php echo base_url().'lalgy/assets/vendor/php-email-form/validate.js';?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url().'lalgy/assets/js/main.js';?>"></script>
  <script src="<?php echo base_url().'lalgy/assets/vendor/aos/aos.js';?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"> </script>






  <script> 
  function sub(){
    //alert("sub");
    var news1=$('#emailidnews1').val();
    var id=$('#emailidnews1').val();
	var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
    if (news1==''){
        $('#newsmsg').html('Please enter Email Id');

    }
    else if (!(testEmail.test(id))){
        $('#newsmsg').html('Please enter Valid Email Id');

    }
    else{
    
    //$("#myForm").submit();
    var emailidnews1=$('#emailidnews1').val();
    var url1="<?php echo base_url().'lalgy/newslettersubscribe';?>"
    $.ajax({
url:url1,
method:"get",
data:{emailidnews1:emailidnews1},
dataType:'text',
crossDomain:true,
success: function(response) {
$('input[type=text]').each(function() {
$(this).val('');
});

$('#emailidnews1').val('');

$('#newsmsg').html(response);

}
               
});		

} 

}
</script>



<script>

$('form[id="frmcontact"]').validate({  
    rules: {  
      first_name: 'required',  
      //last_name: 'required',
      phone:'required',  
      email: {  
        required: true,  
        email: true,  
      }, 
      message:"required", 
      /*psword: {  
        required: true,  
        minlength: 8,  
      }*/  
    },  
    messages: {  
        first_name: '<font color=#fff>First Name is required',  
        //last_name: 'Last Name is required',  
      phone: 'Enter a valid Phone',
      email: 'Enter a valid Email',  
      /*psword: {  
        minlength: 'Password must be at least 8 characters long'  
      } */
      message:'Please enter Message' 
    },  
    submitHandler: function(form) { 
     
            $.ajax({
	url: form.action,
	type: form.method,
	data: $(form).serialize(),
	success: function(response) {
        $('input[type=text]').each(function() {
        $(this).val('');
    });
    
    $("#email").val('');
    $("#message").val('');
    
		$('.msg').html(response);
	}            
      });		
}





      //form.submit();  
   // }  
  });  
  </script>
