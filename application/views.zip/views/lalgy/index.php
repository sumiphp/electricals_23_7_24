<!--DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Lalgy Printers & Advertisers</title>
  <meta content="India’s leading out-of-home agency in its class.
  Lalgy Printers was started in the year 1981 and running successfully as a leading printing and advertising firm in Central Travencore." name="description">
  <meta content="lalgy advertisers & printers, lalgy, advertising, printing, best advertising agency in kerala, best advertising agency in kottayam" name="keywords">
  <meta content="lalgy" name="keywords">

  
  <link href="assets/img/favicon.ico" rel="icon">
  
  <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,500,600,700" rel="stylesheet">
 
  
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/responsive.css" rel="stylesheet">
  
</head>

<body>


 <div class="click-closed"></div>

 <div class="box-collapse">
   <div class="title-box-d">
     <h3 class="title-d">Search Property</h3>
   </div>
   <span class="close-box-collapse right-boxed bi bi-x"></span>
   <div class="box-collapse-wrap form">
     <form class="form-a">
       <div class="row">
         <div class="col-md-12 mb-2">
           <div class="form-group">
             <label class="pb-2" for="Type">Keyword</label>
             <input type="text" class="form-control form-control-lg form-control-a" placeholder="Keyword">
           </div>
         </div>
         <div class="col-md-6 mb-2">
           <div class="form-group mt-3">
             <label class="pb-2" for="Type">Type</label>
             <select class="form-control form-select form-control-a" id="Type">
               <option>All Type</option>
               <option>For Rent</option>
               <option>For Sale</option>
               <option>Open House</option>
             </select>
           </div>
         </div>
         <div class="col-md-6 mb-2">
           <div class="form-group mt-3">
             <label class="pb-2" for="city">City</label>
             <select class="form-control form-select form-control-a" id="city">
               <option>All City</option>
               <option>Alabama</option>
               <option>Arizona</option>
               <option>California</option>
               <option>Colorado</option>
             </select>
           </div>
         </div>
         <div class="col-md-6 mb-2">
           <div class="form-group mt-3">
             <label class="pb-2" for="bedrooms">Bedrooms</label>
             <select class="form-control form-select form-control-a" id="bedrooms">
               <option>Any</option>
               <option>01</option>
               <option>02</option>
               <option>03</option>
             </select>
           </div>
         </div>
         <div class="col-md-6 mb-2">
           <div class="form-group mt-3">
             <label class="pb-2" for="garages">Garages</label>
             <select class="form-control form-select form-control-a" id="garages">
               <option>Any</option>
               <option>01</option>
               <option>02</option>
               <option>03</option>
               <option>04</option>
             </select>
           </div>
         </div>
         <div class="col-md-6 mb-2">
           <div class="form-group mt-3">
             <label class="pb-2" for="bathrooms">Bathrooms</label>
             <select class="form-control form-select form-control-a" id="bathrooms">
               <option>Any</option>
               <option>01</option>
               <option>02</option>
               <option>03</option>
             </select>
           </div>
         </div>
         <div class="col-md-6 mb-2">
           <div class="form-group mt-3">
             <label class="pb-2" for="price">Min Price</label>
             <select class="form-control form-select form-control-a" id="price">
               <option>Unlimite</option>
               <option>$50,000</option>
               <option>$100,000</option>
               <option>$150,000</option>
               <option>$200,000</option>
             </select>
           </div>
         </div>
         <div class="col-md-12">
           <button type="submit" class="btn btn-b">Search Property</button>
         </div>
       </div>
     </form>
   </div>
 </div>

  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto"><img src="assets/img/logo.jpg" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="index.html">Home</a></li>
          <li><a class="nav-link scrollto" href="about.html">About</a></li>
          <li><a class="nav-link scrollto" href="service.html">Services</a></li>
          <li><a class="nav-link   scrollto" href="our-work.html">Our Work</a></li>
          <li><a class="nav-link   scrollto" href="advertisers.html">advertisers</a></li>
          <li><a class="nav-link scrollto" href="contact.html">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <button type="button" class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01">
        <i class="bi bi-search"></i>
      </button>
    </div>
  </header-->

 

  <!-- ======= hero Section ======= -->
   <!-- ======= Intro Section ======= -->

   <?php include('header.php');?>
   <div class="intro intro-carousel swiper position-relative">

    <div class="swiper-wrapper">


    <?php foreach($result2 as $re){?>

      <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(<?php echo base_url().'uploads/carousel/'.$re['picture'];?>)">
        <div class="overlay overlay-a"></div>
        <div class="intro-content display-table">
          <div class="table-cell">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="intro-body">
                    
                    <h1 class="intro-title mb-4 ">
                    <?php echo $re['title'];?>
                    </h1>
                    
                      <a href="<?php echo base_url().'lalgy/services';?>" class="banner-btn">View More</a>
                 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php } ?>


      <!--div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(assets/img/banner-2.png)">
        <div class="overlay overlay-a"></div>
        <div class="intro-content display-table">
          <div class="table-cell">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="intro-body">
                    
                    <h1 class="intro-title mb-4 ">
                      Lalgy Advertisers Services
                    </h1>
                    
                      <a href="#" class="banner-btn">View More</a>
                 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(assets/img/banner-3.png)">
        <div class="overlay overlay-a"></div>
        <div class="intro-content display-table">
          <div class="table-cell">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="intro-body">
                    
                    <h1 class="intro-title mb-4 ">
                      Lalgy Printers  Services
                    </h1>
                    
                      <a href="#" class="banner-btn">View More</a>
                 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(assets/img/banner-4.png)">
        <div class="overlay overlay-a"></div>
        <div class="intro-content display-table">
          <div class="table-cell">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="intro-body">
                    
                    <h1 class="intro-title mb-4 ">
                      Lalgy Printers  Services
                    </h1>
                    
                      <a href="#" class="banner-btn">View More</a>
                 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div-->
    </div>
    <div class="swiper-pagination"></div>
  </div><!-- End Intro Section -->

  <main id="main">

     <!-- ======= About  Section ======= -->
     <section class="intro-single" id="about">
      <div class="container" >
        <div class="row">
          <div class="col-md-6 col-lg-6 col-xs-12">
            <div class="title-single-box"  data-aos="fade-u">
              <h1 class="small-title"><?php echo $resulthome->title1;?></h1>
              <h2 class="single-title"><?php echo $resulthome->title2;?></h2>
              <a href="<?php echo base_url().'lalgy/about';?>" class="view-btn">View More</a>
            </div>
          </div>
          <div class="col-md-6 col-lg-6 col-xs-12">
           <div class="content-area" data-aos="fade-up">
            <p><?php echo $resulthome->description1;?></p>
           </div>
          </div>
        </div>
              <div class="row align-items-center featured-services">

              <?php foreach($resultdata3 as $con){
                
                if ($con['showinfront']==2){
                
                ?>
                <div class="col-md-6 col-lg-4 col-xs-12 d-flex align-items-stretch mb-5 mb-lg-0">
                  <div class="icon-box aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
                    <div class="icon"><img src="<?php echo base_url().'uploads/tour/'.$con['picture'];?>"/></div>
                    <h4 class="title"><a href=""><?php echo $con['city'];?></a></h4>
                    <p class="description"><?php echo $con['description1'];?></p>
                    <a href="<?php echo base_url().'lalgy/contact';?>" class="enq-btn">Enquiry</a>
                  </div>
                </div>
                <?php }} ?>
                <!--div class="col-md-6 col-lg-4 col-xs-12 d-flex align-items-stretch mb-5 mb-lg-0">
                  <div class="icon-box aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
                    <div class="icon"><img src="assets/img/la-img/icon 2.png"/></div>
                    <h4 class="title"><a href="">Digital Media</a></h4>
                    <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi</p>
                    <a href="#" class="enq-btn">Enquiry</a>
                  </div>
                </div>
                <div class="col-md-6 col-lg-4 col-xs-12 d-flex align-items-stretch mb-5 mb-lg-0">
                  <div class="icon-box aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
                    <div class="icon"><img src="assets/img/la-img/icon 3.png"/></div>
                    <h4 class="title"><a href="">Advertising</a></h4>
                    <p class="description">Voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi</p>
                    <a href="#" class="enq-btn">Enquiry</a>
                  </div>
                </div-->




              </div>  </div>
           
          
       


      



     
    </section>




      <!-- ======= Services Section ======= -->

    
   <!-- ======= Background  Section ======= -->
   <section id="cta" class="cta">
    <div class="container aos-init aos-animate" data-aos="zoom-in">

      <div class="row">
        <div class="col-lg-6 col-md-6 text-center text-lg-start">
          <h1 class="small-title"><?php echo $resulthome->title3;?></h1>
          <h2 class="single-title"><?php echo $resulthome->title4;?></h3>
          <p><?php echo $resulthome->description2;?></p>
        
          <ul class="cta-content">
          <?php echo $resulthome->description3;?>
          </ul>
       
       
        </div>
        <div class="col-lg-6 col-md-6 cta-btn-container text-center">
         
        </div>
      </div>

    </div>
  </section>

   

  

    

   <!-- End Latest Properties Section -->
    <section class="section-news section-t8 our-work-sec">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="our-work-area" data-aos="zoom-in">
              <div class="title-box text-center">
                <h2 class="single-title mb-5">OUR WORKS</h3>
              </div>
            </div>
          </div>
        </div>

        <div class="row" >
          <div class="col-lg-4 col-md-4 col-xs-12" data-aos="fade-up">
            <div class="side-bar ">
              <h3>Service category</h3>
              <ul class="custom-scrollbar">
              <?php foreach($resultdata4 as $con){?>
                <li>
                  <a href="<?php echo base_url().'lalgy/services';?>"><?php echo $con['faqtitle'];?></a>
                </li>
                <?php } ?>
                <!--li>
                  <a href="#">Digital Printing</a>
                </li>
                <li>
                  <a href="#">Visiting Cards</a>
                </li>
                <li>
                  <a href="#">Wedding Cards</a>
                </li>
                <li>
                  <a href="#">Calendars</a>
                </li>
                <li>
                  <a href="#">Bill Books</a>
                </li>
                <li>
                  <a href="#">ID Cards</a>
                </li>
                <li>
                  <a href="#">Certificates</a>
                </li>
                <li>
                  <a href="#">Large Format Prints</a>
                </li-->
              </ul>

            </div>
          </div>
          <div class="col-lg-8 col-md-8 col-xs-12" data-aos="fade-up">
            <div class="work-content">
              <div class="row">
              <?php foreach($resultdata as $con){?>

                <?php if ($con['showinfront']==1){?>
                <div class="col-lg-4 col-md-4 col-xs-12">
                  <div class="work-box">
                    <img src="<?php echo base_url().'uploads/dest/'.$con['picture'];?>">
                  </div>
                </div>
                <?php }} ?>
                <!--div class="col-lg-4 col-md-4 col-xs-12">
                  <div class="work-box">
                    <img src="assets/img/service/service-2.png">
                  </div>
                </div>
                <div class="col-lg-4 col-md-4 col-xs-12">
                  <div class="work-box">
                    <img src="assets/img/service/service-3.png">
                  </div>
                </div>
                <div class="col-lg-4 col-md-4 col-xs-12">
                  <div class="work-box">
                    <img src="assets/img/service/service-4.png">
                  </div>
                </div>


                <div class="col-lg-4 col-md-4 col-xs-12">
                  <div class="work-box">
                    <img src="assets/img/service/service-5.png">
                  </div>
                </div>
                <div class="col-lg-4 col-md-4 col-xs-12">
                  <div class="work-box">
                    <img src="assets/img/service/service-6.png">
                  </div>
                </div>

                <div class="col-lg-4 col-md-4 col-xs-12">
                  <div class="work-box">
                    <img src="assets/img/service/service-7.png">
                  </div>
                </div>

                <div class="col-lg-4 col-md-4 col-xs-12">
                  <div class="work-box">
                    <img src="assets/img/service/service-8.png">
                  </div>
                </div>

                <div class="col-lg-4 col-md-4 col-xs-12">
                  <div class="work-box">
                    <img src="assets/img/service/service-9.png">
                  </div>
                </div-->
              </div>
              
            </div>
          </div>
        </div>

        <div id="news-carousel" class="swiper" data-aos="zoom-in">
          <div class="swiper-wrapper">


          <?php foreach($resultdata3 as $con){?>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="<?php echo base_url().'uploads/tour/'.$con['picture'];?>" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="<?php echo base_url().'lalgy/services';?>" class="category-b"><?php echo $con['city'];?></a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="<?php echo base_url().'lalgy/services';?>"><?php echo $con['city'];?>
                           </a>
                      </h2>
                      <p><?php echo $con['city'];?></p>
                    </div>
                    <div class="card-date">
                      <span class="date-b"><?php echo Date('d');?>.<?php echo Date('M');?>.<?php echo Date('Y');?></span>
                    </div>
                    <div class="btn-area">
                      <a href="<?php echo base_url().'lalgy/services';?>" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <?php } ?>

            <!--div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-2.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#"> Card
                          Printing</a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-3.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#"> Card
                          Printing</a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-4.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTINGs</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">News Paper</a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-5.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>


            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-6.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>


            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-7.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-8.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-9.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-10.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-11.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-11.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>


            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-11.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-12.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-13.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-14.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-15.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-16.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="carousel-item-c swiper-slide">
              <div class="card-box-b card-shadow news-box">
                <div class="img-box-b">
                  <img src="assets/img/service/service-slider/slider-17.png" alt="" class="img-b img-fluid">
                </div>
                <div class="card-overlay">
                  <div class="card-header-b">
                    <div class="card-category-b">
                      <a href="#" class="category-b">PRINTING</a>
                    </div>
                    <div class="card-title-b">
                      <h2 class="title-2">
                        <a href="#">Television </a>
                      </h2>
                      <p>Lorem ipsum dolor sit amet, consectetur</p>
                    </div>
                    <div class="card-date">
                      <span class="date-b">18 Sep. 2017</span>
                    </div>
                    <div class="btn-area">
                      <a href="#" class="view-more">View More</a>
                    </div>
                  </div>
                </div>
              </div>
            </div-->

          </div>
        </div>

        <div class="news-carousel-pagination carousel-pagination"></div>
      </div>
    </section> 


  

      <!-- ======= CliENT Section ======= -->

 <!--======= CliENT Section ===-->

    <section class="section-property section-t8 bg-color">
      <div class="container aos-init aos-animate" data-aos="zoom-in">
        <div class="row">
          <div class="col-md-12">
            <div class="our-work-area">
              <div class="title-box text-center">
                <h2 class="single-title mb-5">OUR CLIENTS</h3>
              </div>
            
            </div>
          </div>
        </div>

        <div id="property-carousel" class="swiper">
          <div class="swiper-wrapper">


          <?php foreach($resultdata2 as $con){?>
               
               

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                


                  <img src="<?php echo base_url().'uploads/authority/'.$con['picture'];?>" class="img-fluid" alt="<?php echo $con['alttagimg1'];?>" >
              </div>
            </div>

            <?php } ?>

            <!--div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (2).png" class="img-fluid" alt="">
            </div>
            </div>

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (3).png" class="img-fluid" alt="">
            </div>
            </div>

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (4).png" class="img-fluid" alt="">
            </div>
            </div>

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (5).png" class="img-fluid" alt="">
            </div>
            </div-->

          </div>
        </div>
        <div class="propery-carousel-pagination carousel-pagination"></div>

      </div>
    </section><!-- End Latest Properties Section -->

    <!-- ======= Testimonials Section ======= -->
    <section class="section-testimonials nav-arrow-a ">
      <div class="container">
        <div class="row">
          <div class="col-md-12"  data-aos="zoom-in">
            <div class="testimonial-wrap ">
              <div class="title-box">
                <h2 class="single-title text-center">OUR TESTIMONIALS</h3>
               
              </div>
            </div>
          </div>
        </div>

        <div id="testimonial-carousel" class="swiper"  data-aos="fade-up">
          <div class="swiper-wrapper">

          <?php foreach($resulttest as $test){?>

            <div class="carousel-item-a swiper-slide">
              <div class="testimonials-box">
                <div class="row">
                 
                  <div class="col-sm-12 col-md-12">
                    <div class="testimonial-ico">
                      <i class="bi bi-chat-quote-fill"></i>
                    </div>
                    <div class="testimonials-content">
                      <p class="testimonial-text">
                      <?php echo $test['testimonial'];?>
                      </p>
                    </div>
                    <div class="testimonial-author-box">
                      <img src="<?php echo base_url().'uploads/testimonial/'.$test['image'];?>" alt="<?php echo $test['alttagimg1'];?>" class="testimonial-avatar">
                    
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <?php } ?>

            <!--div class="carousel-item-a swiper-slide">
              <div class="testimonials-box box-center">
                <div class="row">
                 
                  <div class="col-sm-12 col-md-12">
                    <div class="testimonial-ico">
                      <i class="bi bi-chat-quote-fill"></i>
                    </div>
                    <div class="testimonials-content">
                      <p class="testimonial-text">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis, cupiditate ea nam praesentium
                        debitis hic ber quibusdam
                        voluptatibus officia expedita corpori.
                      </p>
                    </div>
                    <div class="testimonial-author-box">
                      <img src="assets/img/mini-testimonial-2.jpg" alt="" class="testimonial-avatar">
                    
                    </div>
                  </div>
                </div>
              </div>
            </div>


            <div class="carousel-item-a swiper-slide">
              <div class="testimonials-box">
                <div class="row">
                 
                  <div class="col-sm-12 col-md-12">
                    <div class="testimonial-ico">
                      <i class="bi bi-chat-quote-fill"></i>
                    </div>
                    <div class="testimonials-content">
                      <p class="testimonial-text">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis, cupiditate ea nam praesentium
                        debitis hic ber quibusdam
                        voluptatibus officia expedita corpori.
                      </p>
                    </div>
                    <div class="testimonial-author-box">
                      <img src="assets/img/mini-testimonial-2.jpg" alt="" class="testimonial-avatar">
                     
                    </div>
                  </div>
                </div>
              </div>
            </div-->

          </div>
        </div>
        <div class="testimonial-carousel-pagination carousel-pagination"></div>

      </div>
    </section><!-- End Testimonials Section -->

  </main><!-- End #main -->

     <!-- ======= Contact Section ======= -->
     <section id="contact" class="contact">
      <div class="container aos-init aos-animate" data-aos="fade-up">

        <div class="row">
          <div class="col-md-12">
            <div class="testimonial-wrap ">
              <div class="title-box mb-5">
                <h2 class="single-title text-center">CONTACT DETAILS</h3>
               
              </div>
            </div>
          </div>
        </div>

        

        <div class="row aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-6 ">
            <!--iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%; height: 384px;" allowfullscreen=""></iframe-->
              <iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3936.412069949042!2d76.57264043863749!3d9.385183090729834!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b06247267357811%3A0xa5e97b8e5264a217!2sLalgy%20Printers%20%26%20Advertisers!5e0!3m2!1sen!2sin!4v1713008642191!5m2!1sen!2sin" frameborder="0" style="border:0; width: 100%; height:384px;" allowfullscreen=""></iframe>
          </div>

          <div class="col-lg-6">
            <form method="post" action="<?php echo base_url().'lalgy/contactenquiryprocess';?>"  role="form" class="php-email-form" id='frmcontact' >
              <div class="row">
                <div class="col form-group">
                  <input type="text" name="first_name" class="form-control" id="first_name" placeholder="Your Name" required="">
                </div>
                <div class="col form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required="">
                </div>

                <div class="col form-group">
                  <input type="text" class="form-control" name="phone" id="phone" placeholder="Your Phone" required="">
                </div>

              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required="">
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" id="message" rows="5" placeholder="Message" required=""></textarea>
              </div>
              <div class="error-message msg"></div>
              <!--div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div-->
              <div class="text-center"><button type="submit">Send Message</button></div>

              <div class="error-message1 msg"></div>
            </form>
          </div>

        </div>

      </div>
    </section>
  <!-- ======= Footer ======= -->
  <!--section class="section-footer">
    <div class="container">
      <div class="row"  data-aos="zoom-in">
        <div class="col-sm-12 col-md-3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Newsletter</h3>
            </div>
            <div class="w-body-a">
              <p class="w-text-a color-text-a">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
              </p>
            </div>
            <div class="newsletter-area">
              <form action="" method="post">
                <input type="email" name="email"><input type="submit" value="Subscribe">
              </form>
              
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Information</h3>
            </div>
            <div class="w-body-a">
              <div class="w-body-a">
                <ul class="list-unstyled">
                  <li class="item-list-a">
                   <a href="#">Site Map</a>
                  </li>
                  <li class="item-list-a">
                  <a href="#">Legal</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Agent Admin</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Careers</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Affiliate</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Privacy Policy</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Customer Service</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
              <a href="#">Venezuela</a>
                </li>
                <li class="item-list-a">
                  <a href="#">China</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Hong Kong</a>
                </li>
                <li class="item-list-a">
                <a href="#">Argentina</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Singapore</a>
                </li>
                <li class="item-list-a">
                  <a href="#">Philippines</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Contact</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
                <a href="#">768 Market Street San Francisco, CA 64015, United States</a>
                </li>
                <li class="item-list-a">
                   <a href="#">   <i class="bi bi-envelope"></i> Customer@gmail.com</a>
                </li>

                <li class="item-list-a">
                  <a href="tel:6743292022">  <i class="bi bi-telephone"></i>  6743292022</a>
               </li>
               
              </ul>
            </div>

            <div class="socials-a">
              <ul class="list-inline">
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-facebook" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-twitter" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-instagram" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-linkedin" aria-hidden="true"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        
          
          <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright 
            <B> Lalgy Printers & Advertisers </B> . All Rights Reserved.
            </p>
          </div>
         
        </div>
      </div>
    </div>
  </footer>

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  
  <script src="assets/js/main.js"></script>
  <script src="assets/vendor/aos/aos.js"></script-->

  <script>

$('form[id="frmcontact"]').validate({  
    rules: {  
      first_name: 'required',  
      //last_name: 'required',
      phone:'required',  
      email: {  
        required: true,  
        email: true,  
      },
      //purpose:"required", 
      subject:"required",
      message:"required", 
      /*psword: {  
        required: true,  
        minlength: 8,  
      }*/  
    },  
    messages: {  
       first_name: '<font color=#fff>First Name is required</font>',  
        //last_name: 'Last Name is required',  
      phone: '<font color=#fff>Enter a valid Phone</font>',
      email: '<font color=#fff>Enter a valid Email</font>',  
      /*psword: {  
        minlength: 'Password must be at least 8 characters long'  
      } */
      //purpose: '<font color=#fff>Enter Purpose</font>',
       subject: '<font color=#fff>Enter Subject</font>',
      message:'<font color=#fff>Please enter Message</font>' 
    },  
    submitHandler: function(form) { 
     
            $.ajax({
	url: form.action,
	type: form.method,
	data: $(form).serialize(),
	success: function(response) {
        $('input[type=text]').each(function() {
        $(this).val('');
    });
    
    $("#email").val('');
    $("#message").val('');
    
		$('.msg').html(response);
	}            
      });		
}





      //form.submit();  
   // }  
  });  
  </script>








  <?php include('footer.php');?>



  <script>
    AOS.init();
  </script>
</body>

</html>