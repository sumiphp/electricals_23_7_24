<!--!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Lalgy Printers & Advertisers</title>
  <meta content="India’s leading out-of-home agency in its class.
  Lalgy Printers was started in the year 1981 and running successfully as a leading printing and advertising firm in Central Travencore." name="description">
  <meta content="lalgy advertisers & printers, lalgy, advertising, printing, best advertising agency in kerala, best advertising agency in kottayam" name="keywords">
  <meta content="lalgy" name="keywords">

  
  


  <link href="assets/img/favicon.ico" rel="icon">
  
  <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,500,600,700" rel="stylesheet">
 
  
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

 
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/responsive.css" rel="stylesheet">
  
</head>

<body>

 
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto"><img src="assets/img/logo.jpg" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="index.html">Home</a></li>
          <li><a class="nav-link scrollto" href="about.html">About</a></li>
          <li><a class="nav-link scrollto" href="service.html">Services</a></li>
          <li><a class="nav-link   scrollto" href="our-work.html">Our Work</a></li>
          <li><a class="nav-link   scrollto" href="advertisers.html">advertisers</a></li>
          <li><a class="nav-link scrollto" href="contact.html">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <button type="button" class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01">
        <i class="bi bi-search"></i>
      </button>
    </div>
  </header-->
  <?php include('header.php');?>

  <main id="main">


   <div class="intro intro-carousel swiper position-relative">

    <div class="swiper-wrapper">
    <?php foreach($result2 as $re){?>

      <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(<?php echo base_url().'uploads/carousel/'.$re['picture'];?>)">
        <div class="overlay overlay-a"></div>
        <div class="intro-content display-table">
          <div class="table-cell">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="intro-body text-center">
                    
                    <h1 class="intro-title mb-4 ">
                    <?php echo $re['title'];?>
                    </h1>
                    <p>  <?php echo $re['title2'];?></p>
                    
                     
                 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php } ?>





      <!--div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(assets/img/service-page/banner-2.png)">
        <div class="overlay overlay-a"></div>
        <div class="intro-content display-table">
          <div class="table-cell">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="intro-body text-center">
                    
                    <h1 class="intro-title mb-4 ">
                      Our Service
                    </h1>
                    <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
                    
                     
                 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="swiper-slide carousel-item-a intro-item bg-image" style="background-image: url(assets/img/service-page/banner-3.png)">
        <div class="overlay overlay-a"></div>
        <div class="intro-content display-table">
          <div class="table-cell">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="intro-body text-center">
                    
                    <h1 class="intro-title mb-4 ">
                      Our Service
                    </h1>
                    <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
                    
                     
                 
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div-->

      
    </div>
    <div class="swiper-pagination"></div>
  </div><!-- End Intro Section -->

    <!-- ======= Property Grid ======= -->
    <section class="property-grid grid section-t4">
      <div class="container">
        <div class="row">
        <?php foreach($resultdata as $con){?>

          <div class="col-md-4">
            <div class="box-service">
            <div class="card-box-a card-shadow">
              <div class="img-box-a">
                <img src="<?php echo base_url().'uploads/tour/'.$con['picture'];?>" alt="<?php echo $con['alttagimg1'];?>" class="img-a img-fluid">
              </div>
            </div>
            <div class="card-content-area">
               <h2><?php echo $con['city'];?></h2>
               <p><?php echo $con['description1'];?></p>
               <a href="<?php echo base_url().'lalgy/contact';?>" class="enq-btn">Enquiry</a>
            </div>
          </div>
          </div>



          <?php } ?>
        
          <!--div class="col-md-4">
            <div class="box-service">
            <div class="card-box-a card-shadow">
              <div class="img-box-a">
                <img src="assets/img/service-page/ser-1.png" alt="" class="img-a img-fluid">
              </div>
            </div>
            <div class="card-content-area">
               <h2>Printing</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
               <a href="#" class="enq-btn">Enquiry</a>
            </div>
          </div>
          </div>
          <div class="col-md-4">
            <div class="box-service">
            <div class="card-box-a card-shadow">
              <div class="img-box-a">
                <img src="assets/img/service-page/ser-6.png" alt="" class="img-a img-fluid">
              </div>
            </div>
            <div class="card-content-area">
               <h2>Printing</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
               <a href="#" class="enq-btn">Enquiry</a>
            </div>
          </div>
        </div>
          <div class="col-md-4">
            <div class="box-service">
            <div class="card-box-a card-shadow">
              <div class="img-box-a">
                <img src="assets/img/service-page/ser-2.png" alt="" class="img-a img-fluid">
              </div>
            </div>
            <div class="card-content-area">
               <h2>Printing</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
               <a href="#" class="enq-btn">Enquiry</a>
            </div>
          </div>
          </div>
          <div class="col-md-4">
            <div class="box-service">
            <div class="card-box-a card-shadow">
              <div class="img-box-a">
                <img src="assets/img/service-page/ser-3.png" alt="" class="img-a img-fluid">
              </div>
            </div>
            <div class="card-content-area">
               <h2>Printing</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
               <a href="#" class="enq-btn">Enquiry</a>
            </div>
          </div>
          </div>
          <div class="col-md-4">
            <div class="box-service">
            <div class="card-box-a card-shadow">
              <div class="img-box-a">
                <img src="assets/img/service-page/ser-4.png" alt="" class="img-a img-fluid">
              </div>
            </div>
            <div class="card-content-area">
               <h2>Printing</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
               <a href="#" class="enq-btn">Enquiry</a>
            </div>
          </div>
        </div>
          <div class="col-md-4">
            <div class="box-service">
            <div class="card-box-a card-shadow">
              <div class="img-box-a">
                <img src="assets/img/service-page/ser-5.png" alt="" class="img-a img-fluid">
              </div>
            </div>
            <div class="card-content-area">
               <h2>Printing</h2>
               <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
               <a href="#" class="enq-btn">Enquiry</a>
            </div>
          </div-->
        </div>
      </div>
        <!--div class="row">
          <div class="col-sm-12">
            <nav class="pagination-a">
              <ul class="pagination justify-content-end">
                <li class="page-item disabled">
                  <a class="page-link" href="#" tabindex="-1">
                    <span class="bi bi-chevron-left"></span>
                  </a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item ">
                  <a class="page-link" href="#">2</a>
                </li>
                <li class="page-item">
                  <a class="page-link" href="#">3</a>
                </li>
                <li class="page-item next">
                  <a class="page-link" href="#">
                    <span class="bi bi-chevron-right"></span>
                  </a>
                </li>
              </ul>
            </nav>
          </div>
        </div-->
      </div>
    </section><!-- End Property Grid Single-->

  </main>
  
  <?php include('footer.php');?>
  
  
  
  <!-- End #main -->
  <!-- ======= Footer ======= -->
  <!--section class="section-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Newsletter</h3>
            </div>
            <div class="w-body-a">
              <p class="w-text-a color-text-a">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
              </p>
            </div>
            <div class="newsletter-area">
              <form action="" method="post">
                <input type="email" name="email"><input type="submit" value="Subscribe">
              </form>
              
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Information</h3>
            </div>
            <div class="w-body-a">
              <div class="w-body-a">
                <ul class="list-unstyled">
                  <li class="item-list-a">
                   <a href="#">Site Map</a>
                  </li>
                  <li class="item-list-a">
                  <a href="#">Legal</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Agent Admin</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Careers</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Affiliate</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Privacy Policy</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Customer Service</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
              <a href="#">Venezuela</a>
                </li>
                <li class="item-list-a">
                  <a href="#">China</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Hong Kong</a>
                </li>
                <li class="item-list-a">
                <a href="#">Argentina</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Singapore</a>
                </li>
                <li class="item-list-a">
                  <a href="#">Philippines</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Contact</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
                <a href="#">768 Market Street San Francisco, CA 64015, United States</a>
                </li>
                <li class="item-list-a">
                  <a href="#">   <i class="bi bi-envelope"></i> Customer@gmail.com</a>
               </li>

               <li class="item-list-a">
                 <a href="tel:6743292022">  <i class="bi bi-telephone"></i>  6743292022</a>
              </li>
               
              </ul>
            </div>

            <div class="socials-a">
              <ul class="list-inline">
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-facebook" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-twitter" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-instagram" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-linkedin" aria-hidden="true"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright 
            <B> Lalgy Printers & Advertisers </B> . All Rights Reserved.
            </p>
          </div>
         
        </div>
      </div>
    </div>
  </footer>

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

 
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>


  <script src="assets/js/main.js"></script-->

</body>

</html>