<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Lalgy Printers & Advertisers</title>
  <meta content="India’s leading out-of-home agency in its class.
  Lalgy Printers was started in the year 1981 and running successfully as a leading printing and advertising firm in Central Travencore." name="description">
  <meta content="lalgy advertisers & printers, lalgy, advertising, printing, best advertising agency in kerala, best advertising agency in kottayam" name="keywords">
  <meta content="lalgy" name="keywords">

  <!-- Favicons -->
  <!-- <link href="assets/img/favicon.png" rel="icon"> -->
  

  <!-- Google Fonts -->
  <link href="<?php echo base_url().'lalgy/assets/img/favicon.ico';?>" rel="icon">
  
  <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,500,600,700" rel="stylesheet">
  <!-- Vendor CSS Files -->
  
  <link href="<?php echo base_url().'lalgy/assets/vendor/aos/aos.css';?>" rel="stylesheet">
  <link href="<?php echo base_url().'lalgy/assets/vendor/animate.css/animate.min.css';?>" rel="stylesheet">
  <link href="<?php echo base_url().'lalgy/assets/vendor/bootstrap/css/bootstrap.min.css';?>" rel="stylesheet">
  <link href="<?php echo base_url().'lalgy/assets/vendor/bootstrap-icons/bootstrap-icons.css';?>" rel="stylesheet">
  <link href="<?php echo base_url().'lalgy/assets/vendor/swiper/swiper-bundle.min.css';?>" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url().'lalgy/assets/css/style.css';?>" rel="stylesheet">
  <link href="<?php echo base_url().'lalgy/assets/css/responsive.css';?>" rel="stylesheet">

</head>

<body>



  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <a href="<?php echo base_url().'lalgy/index';?>" class="logo me-auto"><img src="assets/img/logo.jpg" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="<?php echo base_url().'lalgy/index';?>">Home</a></li>
          <li><a class="nav-link scrollto" href="<?php echo base_url().'lalgy/about';?>">About</a></li>
          <li><a class="nav-link scrollto" href="<?php echo base_url().'lalgy/services';?>">Services</a></li>
          <li><a class="nav-link   scrollto" href="<?php echo base_url().'lalgy/ourwork';?>">Our Work</a></li>
          <li><a class="nav-link   scrollto" href="<?php echo base_url().'lalgy/advertisers';?>">Advertisers</a></li>
          <li><a class="nav-link scrollto" href="<?php echo base_url().'lalgy/contact';?>">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      <!--button type="button" class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01">
        <i class="bi bi-search"></i>
      </button-->
    </div>
  </header>