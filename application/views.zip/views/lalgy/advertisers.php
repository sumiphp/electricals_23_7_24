<!--!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Lalgy Printers & Advertisers</title>
  <meta content="India’s leading out-of-home agency in its class.
  Lalgy Printers was started in the year 1981 and running successfully as a leading printing and advertising firm in Central Travencore." name="description">
  <meta content="lalgy advertisers & printers, lalgy, advertising, printing, best advertising agency in kerala, best advertising agency in kottayam" name="keywords">
  <meta content="lalgy" name="keywords">

  
  <link href="assets/img/favicon.ico" rel="icon">
  
  <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,500,600,700" rel="stylesheet">
 
  
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">


  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/responsive.css" rel="stylesheet">
  
</head>

<body>




  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto"><img src="assets/img/logo.jpg" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="index.html">Home</a></li>
          <li><a class="nav-link scrollto" href="about.html">About</a></li>
          <li><a class="nav-link scrollto" href="service.html">Services</a></li>
          <li><a class="nav-link   scrollto" href="our-work.html">Our Work</a></li>
          <li><a class="nav-link   scrollto" href="advertisers.html">advertisers</a></li>
          <li><a class="nav-link scrollto" href="contact.html">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <button type="button" class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01">
        <i class="bi bi-search"></i>
      </button>
    </div>
  </header-->

  <?php include('header.php');?>

  <main id="main">

    <!-- ======= Intro Single ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">ADVERTISEMENT</h1>
          
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="index.html">Home</a>
                </li>
                <li class="breadcrumb-item active">
                  <a href="advertisers.html">ADVERTISEMENT</a>
                </li>
                
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- End Intro Single-->

    <!-- ======= Property Single ======= -->

    <?php 
    
    $arr=array();
    $arr1=array();
    $i=0;
    foreach($resultdata as $con){ 
            
            if ($con['top']=='1'){
              
              $arr[$i]=$con['picture'];
              $arr1[$i]=$con['description1'];
              $i++;

            }}?>




    <section class="property-single nav-arrow-b">
      <div class="container">
        <div class="row ">
          <div class="col-lg-7">
            <div id="property-single-carousel" class="swiper">
              <div class="swiper-wrapper">
                <div class="carousel-item-b swiper-slide">
                  <img src="<?php echo base_url().'uploads/packages/'.$arr[0];?>" alt="" style="background-repeat: no-repeat;">
                </div>
                <div class="carousel-item-b swiper-slide">
                  <img src="<?php echo base_url().'uploads/packages/'.$arr[1];?>" alt="" style="background-repeat: no-repeat;background-size: cover;">
                </div>
              </div>
            </div>
            <div class="property-single-carousel-pagination carousel-pagination"></div>
          </div>
          <div class="col-lg-5">
            <div class="content-area">

           <?php echo $arr1[0];?>
              <!--p>Lalgy Advertisers are more concentrated on media buying. Marketing is more than what you imagine. It is all about visibility and reaching a targeted audience. We provides advertising, media, marketing communications, public relations (PR), event organization and other services to help businesses and organizations raise awareness, sell products and services, and create dynamic brands.</p>

               <p> Advertising should reflect the qualities of the product you are planning to sell. Lalgy will work as a mirror to reflect and project the qualities of your products to the customers. Our services will vary from idea generation to implementation. Our Ad creatives are free of cost for regular clients based on the media strategy. We provide best ad space based on the media strategy at a minimum cost. Multimedia, print, and radio campaigns are provided to clients at the best price compared to other agencies.</p>
                
               <p> We do market research, planning and budgeting advertising, coordinating multichannel marketing campaign. We offer services like Ad campaigns, social media management, content creation, graphic design, strategic planning, TV/web/radio commercials.</p>
                
               <p> We can help our clients to develop their brand, gain professional expertise, expand company’s reach and improve brand’s image. Our agency place your creative advertising materials in the most optimal locations, whether they're printed or digital. We can provide recommendations on timing and amount your company should spend for the best results when it comes to marketing your product or service.</p-->
            </div>
           
          </div>
        </div>

        
      </div>
    </section><!-- End Property Single-->
    <section id="ad" class="ad mt-3">
      <div class="container aos-init aos-animate" data-aos="zoom-in">

        <div class="row">
          <div class="col-lg-12 text-center text-lg-start">

          <?php foreach($resultdata as $con){ 
            
            if ($con['city']=='NEWS PAPER ADVERTISEMENT'){
            
            ?>



            <h3 class="pb-2"><?php echo $con['city'];?></h3>
            <p><?php echo $con['description1'];?></p>
            <!--p>Newspaper display advertising is a form of newspaper advertisement - where the advertisement appears alongside regular editorial content. Display ads are generally used by businesses and corporations towards promotion of their goods and services and are generally for larger budget clients. Display ads appear in all sections of the newspaper except the editorial page, obituary page, and classified section.</p>

            <p> These ads can span across multiple columns - and can even cover full page, half page, quarter page or other custom sizes. They are designed in high resolution coloured and black/white formats providing higher visibility for the mass audiences of newspapers. For many major newspapers in developing markets, display ads play a significant role in subsidizing the cost of the published newspaper.</p>
             
            <p>Newspaper display ads are different from the regular "display ads" terminology, which is commonly referred to as advertisements placed on the internet in banner and other rich media format..</p-->
            <?php }} ?>
          </div>
         
        </div>

      </div>
    </section>

    <section class="section-t4">
      <div class="Television-ad">
        <div class="container">


        



        <?php foreach($resultdata as $con){
           if ($con['top']!='1'){
          
          if ($con['city']!='NEWS PAPER ADVERTISEMENT'){
          
          ?>
          <div class="row">
            <div class="col-lg-6 col-xs-12 col-md-6">
              <div class="content-area">
                <div class="title-box-d">
                  <h3 class="title-d"><?php echo $con['city'];?></h3>
                </div>
                
                <p>
                <?php echo $con['description1'];?>
                </p>
              </div>
            </div>

            <div class="col-lg-6 col-xs-12 col-md-6">
              <div class="img-area">
                <img src="<?php echo base_url().'uploads/packages/'.$con['picture'];?>"  alt="<?php echo $con['alttagimg1'];?>" />
              </div>
            </div>
          </div>

<?php }}} ?>


        </div>
      </div>
    </section>
  </main>
  
  <?php include('footer.php');?>
  
  
  
  <!-- End #main -->

  <!-- ======= Footer ======= -->
  <!-- ======= Footer ======= -->



  <!--section class="section-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Newsletter</h3>
            </div>
            <div class="w-body-a">
              <p class="w-text-a color-text-a">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
              </p>
            </div>
            <div class="newsletter-area">
              <form action="" method="post">
                <input type="email" name="email"><input type="submit" value="Subscribe">
              </form>
              
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Information</h3>
            </div>
            <div class="w-body-a">
              <div class="w-body-a">
                <ul class="list-unstyled">
                  <li class="item-list-a">
                   <a href="#">Site Map</a>
                  </li>
                  <li class="item-list-a">
                  <a href="#">Legal</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Agent Admin</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Careers</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Affiliate</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Privacy Policy</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Customer Service</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
              <a href="#">Venezuela</a>
                </li>
                <li class="item-list-a">
                  <a href="#">China</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Hong Kong</a>
                </li>
                <li class="item-list-a">
                <a href="#">Argentina</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Singapore</a>
                </li>
                <li class="item-list-a">
                  <a href="#">Philippines</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Contact</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
                <a href="#">768 Market Street San Francisco, CA 64015, United States</a>
                </li>
                <li class="item-list-a">
                  <a href="#">   <i class="bi bi-envelope"></i> Customer@gmail.com</a>
               </li>

               <li class="item-list-a">
                 <a href="tel:6743292022">  <i class="bi bi-telephone"></i>  6743292022</a>
              </li>
               
              </ul>
            </div>

            <div class="socials-a">
              <ul class="list-inline">
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-facebook" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-twitter" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-instagram" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-linkedin" aria-hidden="true"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright 
            <B> Lalgy Printers & Advertisers </B> . All Rights Reserved.
            </p>
          </div>
         
        </div>
      </div>
    </div>
  </footer>

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

 
  <script src="assets/js/main.js"></script-->

</body>

</html>