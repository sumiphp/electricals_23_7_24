<?php include('header.php');?>

  <main id="main">

    <!-- ======= Intro Single ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single"><?php echo $about->title;?></h1>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="#">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  About
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- End Intro Single-->

    <!-- ======= About Section ======= -->
    <section class="section-about">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 position-relative">
            <div class="about-img-box">

            <?php $url=base_url().'uploads/aboutus/'.$about->aboutusbanner;?>

            
              <img src="<?php echo $url;?>" alt="" class="img-fluid">
            </div>
            <div class="sinse-box">
              <h3 class="sinse-title">Lalgy
                <span></span>
                <br> Printer and advertisers
              </h3>
              <p><?php echo $about->aboutusshortdesc;?></p>
            </div>
          </div>
          <div class="col-md-12 section-t4 position-relative">
            <div class="row">
              <div class="col-md-6 col-lg-6">
                <div class="title-box-d">
                  <h3 class="title-d">Mission
                    
                 
                  </h3>
                </div>
                <p class="color-text"><?php echo $about->mission;?>
                
                </p>
                <p class="color-text"><?php echo $about->mission;?>
                 
                </p>
                
              </div>
             
              <div class="col-md-6 col-lg-6">
                <div class="title-box-d">
                  <h3 class="title-d">Vision
                   
                 
                  </h3>
                </div>
                <p class="color-text"><?php echo $about->vision;?>
                 
                </p>

                <p class="color-text"><?php echo $about->vision;?>
                 
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="counts" class="counts">
      <div class="container aos-init aos-animate" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="count-box">
              <i class="bi bi-emoji-smile"></i>
              <span data-purecounter-start="0" data-purecounter-end="232" data-purecounter-duration="0" class="purecounter"><?php echo $about->happyclients;?></span>
              <p>Happy Clients</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
            <div class="count-box">
              <i class="bi bi-journal-richtext"></i>
              <span data-purecounter-start="0" data-purecounter-end="521" data-purecounter-duration="0" class="purecounter"><?php echo $about->nohotels;?></span>
              <p>Projects</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="bi bi-headset"></i>
              <span data-purecounter-start="0" data-purecounter-end="1463" data-purecounter-duration="0" class="purecounter">
              <?php echo $about->notravels;?>
              </span>
              <p>Years of Experience</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="bi bi-people"></i>
              <span data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="0" class="purecounter"><?php echo $about->nowinning;?></span>
              <p>Awards</p>
            </div>
          </div>

        </div>

      </div>
    </section>
    <!-- =======Team Section ======= -->
    <section class="section-agents section-t8">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="title-wrap">
              <div class="title-box">
                <h2 class="title-a text-center">Meet Our Team</h2>
              </div>
            </div>
          </div>
        </div>
        <div class="row">


        <?php foreach($resultdata as $con){?>


          <?php $url=base_url().'uploads/teammembers/'.$con['picture'];?>
          <div class="col-md-4">
            <div class="card-box-d">
              <div class="card-img-d">
                <img src="<?php echo $url;?>" alt="" class="img-d img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                <div class="card-header-d">
                  <div class="card-title-d align-self-center">
                    <h3 class="title-d">
                      <a href="#" class="link-two"><?php echo $con['name'];?>
                      
                    </h3>
                  </div>
                </div>
                <div class="card-body-d">
                  <p class="content-d color-text-a">
                  <?php echo $con['designation'];?>
                  </p>
                  <div class="info-agents color-a">
                    <p>
                      <strong>Phone: </strong> +<?php echo $con['namear'];?>
                    </p>
                    <p>
                      <strong>Email: </strong>   <?php echo $con['designationar'];?>
                    </p>
                  </div>
                </div>
                <div class="card-footer-d">
                  <div class="socials-footer d-flex justify-content-center">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="<?php echo $con['facebook'];?>" target=_blank class="link-one">
                          <i class="bi bi-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="<?php echo $con['twitter'];?>" class="link-one" target=_blank>
                          <i class="bi bi-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="<?php echo $con['instagram'];?>" class="link-one" target=_blank>
                          <i class="bi bi-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="<?php echo $con['youtube'];?>" class="link-one" target=_blank>
                          <i class="bi bi-linkedin" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>




              </div>
            </div>
          </div>

          <?php } ?>
          <!--div class="col-md-4">
            <div class="card-box-d">
              <div class="card-img-d">
                <img src="assets/img/team-2.png" alt="" class="img-d img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                <div class="card-header-d">
                  <div class="card-title-d align-self-center">
                    <h3 class="title-d">
                      <a href="#" class="link-two">Stiven Spilver--
                     
                    </h3>
                  </div>
                </div>
                <div class="card-body-d">
                  <p class="content-d color-text-a">
                    Sed porttitor lectus nibh, Cras ultricies ligula sed magna dictum porta two.
                  </p>
                  <div class="info-agents color-a">
                    <p>
                      <strong>Phone: </strong> +54 356 945234
                    </p>
                    <p>
                      <strong>Email: </strong> agents@example.com
                    </p>
                  </div>
                </div>
                <div class="card-footer-d">
                  <div class="socials-footer d-flex justify-content-center">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-linkedin" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-dribbble" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div-->



              </div>
            </div>
        </div>


          <!--div class="col-md-4">
            <div class="card-box-d">
              <div class="card-img-d">
                <img src="assets/img/team-1.png" alt="" class="img-d img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                <div class="card-header-d">
                  <div class="card-title-d align-self-center">
                    <h3 class="title-d">
                      <a href="#" class="link-two">Emma Toledo
                      
                    </h3>
                  </div>
                </div>
                <div class="card-body-d">
                  <p class="content-d color-text-a">
                    Sed porttitor lectus nibh, Cras ultricies ligula sed magna dictum porta two.
                  </p>
                  <div class="info-agents color-a">
                    <p>
                      <strong>Phone: </strong> +54 356 945234
                    </p>
                    <p>
                      <strong>Email: </strong> agents@example.com
                    </p>
                  </div>
                </div>
                <div class="card-footer-d">
                  <div class="socials-footer d-flex justify-content-center">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-linkedin" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-dribbble" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div-->



        </div>
      </div>
    </section><!-- End About Section-->


    <!--======= CliENT Section ===-->

    <section class="section-property section-t8 bg-color">
      <div class="container aos-init aos-animate" data-aos="zoom-in">
        <div class="row">
          <div class="col-md-12">
            <div class="our-work-area">
              <div class="title-box text-center">
                <h2 class="single-title mb-5">OUR CLIENTS</h3>
              </div>
            
            </div>
          </div>
        </div>

        <div id="property-carousel" class="swiper">
          <div class="swiper-wrapper">

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                  <img src="assets/img/la-img/our-client/our-1 (1).png" class="img-fluid" alt="">
              </div>
            </div><!-- End carousel item -->

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (2).png" class="img-fluid" alt="">
            </div>
            </div><!-- End carousel item -->

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (3).png" class="img-fluid" alt="">
            </div>
            </div><!-- End carousel item -->

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (4).png" class="img-fluid" alt="">
            </div>
            </div><!-- End carousel item -->

            <div class="carousel-item-b swiper-slide">
              <div class="client-logo">
                <img src="assets/img/la-img/our-client/our-1 (5).png" class="img-fluid" alt="">
            </div>
            </div><!-- End carousel item -->

          </div>
        </div>
        <div class="propery-carousel-pagination carousel-pagination"></div>

      </div>
    </section><!-- End Latest Properties Section -->

  </main><!-- End #main -->
 <!-- ======= Contact Section ======= -->
 <section id="contact" class="contact">
  <div class="container aos-init aos-animate" data-aos="fade-up">

    <div class="row">
      <div class="col-md-12">
        <div class="testimonial-wrap title-wrap">
          <div class="title-box ">
            <h2 class="single-title text-center">CONTACT DETAILS</h3>
           
          </div>
        </div>
      </div>
    </div>

    

    <div class="row aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">

      <div class="col-lg-6 ">
      <iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3936.412069949042!2d76.57264043863749!3d9.385183090729834!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b06247267357811%3A0xa5e97b8e5264a217!2sLalgy%20Printers%20%26%20Advertisers!5e0!3m2!1sen!2sin!4v1713008642191!5m2!1sen!2sin" frameborder="0" style="border:0; width: 100%; height:384px;" allowfullscreen=""></iframe>
        <!--iframe class="mb-4 mb-lg-0" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" style="border:0; width: 100%; height: 384px;" allowfullscreen=""></iframe-->
      </div>

      <div class="col-lg-6">
        <form  method="post" role="form" class="php-email-form" id='frmcontact' action="<?php echo base_url().'lalgy/contactenquiryprocess';?>">
          <div class="row">
            <div class="col form-group">
              <input type="text" name="first_name" class="form-control" id="first_name" placeholder="Your Name" required="">
            </div>
            <div class="col form-group">
              <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required="">
            </div>
          </div>
          <div class="form-group">
            <!--input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required=""-->

 <input type="text" class="form-control" name="phone" id="phone" placeholder="Phone No" required="">

          </div>
          <div class="form-group">
            <textarea class="form-control" name="message" rows="5" placeholder="Message" required=""></textarea>
          </div>
          <div class="my-3">
            <div class="loading">Loading</div>
            <div class="error-message"></div>
            <div class="sent-message">Your message has been sent. Thank you!</div>
          </div>
          <div class="text-center"><button type="submit">Send Message</button></div>
        </form>
      </div>

    </div>

  </div>
</section>
  
</body>

</html>







