<!--!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Lalgy Printers & Advertisers</title>
  <meta content="India’s leading out-of-home agency in its class.
  Lalgy Printers was started in the year 1981 and running successfully as a leading printing and advertising firm in Central Travencore." name="description">
  <meta content="lalgy advertisers & printers, lalgy, advertising, printing, best advertising agency in kerala, best advertising agency in kottayam" name="keywords">
  <meta content="lalgy" name="keywords">

  
  

  <link href="assets/img/favicon.ico" rel="icon">
  
  <link href="https://fonts.googleapis.com/css?family=Nunito:300,400,500,600,700" rel="stylesheet">
  
  
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/responsive.css" rel="stylesheet">
  
</head>

<body>

  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <a href="index.html" class="logo me-auto"><img src="assets/img/logo.jpg" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="index.html">Home</a></li>
          <li><a class="nav-link scrollto" href="about.html">About</a></li>
          <li><a class="nav-link scrollto" href="service.html">Services</a></li>
          <li><a class="nav-link   scrollto" href="our-work.html">Our Work</a></li>
          <li><a class="nav-link   scrollto" href="advertisers.html">advertisers</a></li>
          <li><a class="nav-link scrollto" href="contact.html">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <button type="button" class="btn btn-b-n navbar-toggle-box navbar-toggle-box-collapse" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo01">
        <i class="bi bi-search"></i>
      </button>
    </div>
  </header-->

  <?php include('header.php');?>
  <main id="main">

   
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">Our Work </h1>
            
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="index.html">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                Our Work
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- End Intro Single-->

    <!-- =======  Blog Grid ======= -->
    <section class="news-grid grid">
      <div class="container">
        <div class="row">
        <?php foreach($resultdata as $con){
          
          if ($con['showinfront']==0){
          
          ?>
          <div class="col-md-4">
            <div class="card-box-b card-shadow news-box">
              <div class="img-box-b">
                <img src="<?php echo base_url().'uploads/dest/'.$con['picture']?>" alt="" class="img-b img-fluid">
              </div>
              <div class="card-overlay">
                <div class="card-header-b">
                  <div class="card-category-b">
                    <a href="#" class="category-b"><?php echo $con['city'];?></a>
                  </div>
                  <div class="card-title-b">
                    <h2 class="title-2">
                      <a href="#"><?php echo $con['city'];?>
                      </a>
                    </h2>
                  </div>
                  <div class="card-date">
                    <span class="date-b"> <?php echo Date('d');?>.<?php echo Date('M');?>.<?php echo Date('Y');?></span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php }} ?>
          <!--div class="col-md-4">
            <div class="card-box-b card-shadow news-box">
              <div class="img-box-b">
                <img src="assets/img/our-works/bill book.jpg" alt="" class="img-b img-fluid">
              </div>
              <div class="card-overlay">
                <div class="card-header-b">
                  <div class="card-category-b">
                    <a href="#" class="category-b">Bill Book Printing</a>
                  </div>
                  <div class="card-title-b">
                    <h2 class="title-2">
                      <a href="#">Bill Book Printing
                       </a>
                    </h2>
                  </div>
                  <div class="card-date">
                    <span class="date-b">18 Sep. 2017</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card-box-b card-shadow news-box">
              <div class="img-box-b">
                <img src="assets/img/our-works/weddingcard0001.jpg" alt="" class="img-b img-fluid">
              </div>
              <div class="card-overlay">
                <div class="card-header-b">
                  <div class="card-category-b">
                    <a href="#" class="category-b">Wedding Card</a>
                  </div>
                  <div class="card-title-b">
                    <h2 class="title-2">
                      <a href="#">Wedding Card Printing
                       </a>
                    </h2>
                  </div>
                  <div class="card-date">
                    <span class="date-b">18 Sep. 2017</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card-box-b card-shadow news-box">
              <div class="img-box-b">
                <img src="assets/img/our-works/Booklets.jpg" alt="" class="img-b img-fluid">
              </div>
              <div class="card-overlay">
                <div class="card-header-b">
                  <div class="card-category-b">
                    <a href="#" class="category-b">Booklets Printing</a>
                  </div>
                  <div class="card-title-b">
                    <h2 class="title-2">
                      <a href="#">Booklets Printing
                       </a>
                    </h2>
                  </div>
                  <div class="card-date">
                    <span class="date-b">18 Sep. 2017</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card-box-b card-shadow news-box">
              <div class="img-box-b">
                <img src="assets/img/our-works/idcard0001.jpg" alt="" class="img-b img-fluid">
              </div>
              <div class="card-overlay">
                <div class="card-header-b">
                  <div class="card-category-b">
                    <a href="#" class="category-b">ID Cards Printing</a>
                  </div>
                  <div class="card-title-b">
                    <h2 class="title-2">
                      <a href="#">ID Cards Printing
                       </a>
                    </h2>
                  </div>
                  <div class="card-date">
                    <span class="date-b">18 Sep. 2017</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card-box-b card-shadow news-box">
              <div class="img-box-b">
                <img src="assets/img/our-works/calender001.webp" alt="" class="img-b img-fluid">
              </div>
              <div class="card-overlay">
                <div class="card-header-b">
                  <div class="card-category-b">
                    <a href="#" class="category-b">Calender Printing </a>
                  </div>
                  <div class="card-title-b">
                    <h2 class="title-2">
                      <a href="#">Calender Printing 
                        </a>
                    </h2>
                  </div>
                  <div class="card-date">
                    <span class="date-b">18 Sep. 2017</span>
                  </div>
                </div>
              </div>
            </div>
          </div-->
        </div>
       
      </div>
    </section>
    
    
    <!-- End Blog Grid-->

  </main>
  
  <?php include('footer.php');?>
  
  
  
  
  <!-- End #main -->

   <!-- ======= Footer ======= -->



   <!--section class="section-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Newsletter</h3>
            </div>
            <div class="w-body-a">
              <p class="w-text-a color-text-a">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore
              </p>
            </div>
            <div class="newsletter-area">
              <form action="" method="post">
                <input type="email" name="email"><input type="submit" value="Subscribe">
              </form>
              
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Information</h3>
            </div>
            <div class="w-body-a">
              <div class="w-body-a">
                <ul class="list-unstyled">
                  <li class="item-list-a">
                   <a href="#">Site Map</a>
                  </li>
                  <li class="item-list-a">
                  <a href="#">Legal</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Agent Admin</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Careers</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Affiliate</a>
                  </li>
                  <li class="item-list-a">
                 <a href="#">Privacy Policy</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Customer Service</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
              <a href="#">Venezuela</a>
                </li>
                <li class="item-list-a">
                  <a href="#">China</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Hong Kong</a>
                </li>
                <li class="item-list-a">
                <a href="#">Argentina</a>
                </li>
                <li class="item-list-a">
                 <a href="#">Singapore</a>
                </li>
                <li class="item-list-a">
                  <a href="#">Philippines</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-12 col-md-3 section-md-t3">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a">Contact</h3>
            </div>
            <div class="w-body-a">
              <ul class="list-unstyled">
                <li class="item-list-a">
                <a href="#">768 Market Street San Francisco, CA 64015, United States</a>
                </li>
                <li class="item-list-a">
                  <a href="#">   <i class="bi bi-envelope"></i> Customer@gmail.com</a>
               </li>

               <li class="item-list-a">
                 <a href="tel:6743292022">  <i class="bi bi-telephone"></i>  6743292022</a>
              </li>
               
              </ul>
            </div>

            <div class="socials-a">
              <ul class="list-inline">
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-facebook" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-twitter" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-instagram" aria-hidden="true"></i>
                  </a>
                </li>
                <li class="list-inline-item">
                  <a href="#">
                    <i class="bi bi-linkedin" aria-hidden="true"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright 
            <B> Lalgy Printers & Advertisers </B> . All Rights Reserved.
            </p>
          </div>
         
        </div>
      </div>
    </div>
  </footer>

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

 
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

 
  <script src="assets/js/main.js"></script-->

</body>

</html>